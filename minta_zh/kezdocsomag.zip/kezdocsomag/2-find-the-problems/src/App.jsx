import { TaskB } from "./TaskB/TaskB";
import { TaskA } from "./TaskA/TaskA";

function App() {
  return (
    <>
      <TaskA></TaskA>
      <hr />
      <TaskB></TaskB>
    </>
  );
}

export default App;
