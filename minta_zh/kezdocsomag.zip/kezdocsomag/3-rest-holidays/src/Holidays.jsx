export const Holidays = () => {
  return (
    <>
      <a href="/">Back</a>
      <table>
        <thead>
          <tr>
            <th>Holidays</th>
            <th>
              <input type="number" value="2023" />
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2023-03-15</td>
            <td>1848-as szabadságharc</td>
          </tr>
        </tbody>
      </table>
    </>
  );
};
