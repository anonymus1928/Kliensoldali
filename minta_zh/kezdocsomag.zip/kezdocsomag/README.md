# Nyilatkozat

<Hallgató neve>
<Neptun kódja>
Kliensoldali webprogramozás - ZH
Ezt a megoldást a fent írt hallgató küldte be és készítette
a Kliensoldali webprogramozás kurzus ZH-jához.
Kijelentem, hogy ez a megoldás a saját munkám. Nem másoltam vagy
használtam harmadik féltől származó megoldásokat. Nem továbbítottam
megoldást hallgatótársaimnak, és nem is tettem közzé. Az Eötvös Loránd
Tudományegyetem Hallgatói Követelményrendszere (ELTE szervezeti és
működési szabályzata, II. Kötet, 74/C. §) kimondja, hogy mindaddig,
amíg egy hallgató egy másik hallgató munkáját - vagy legalábbis annak
jelentős részét - saját munkájaként mutatja be, az fegyelmi vétségnek számít.
A fegyelmi vétség legsúlyosabb következménye a hallgató elbocsátása az egyetemről.

# 1. feladat

[ ] a.
[ ] b.
[ ] c.
[ ] d.

# 2. feladat

[ ] Task A
[ ] Task B

# 3. feladat

[ ] a.
[ ] b.
[ ] c.
[ ] d.
[ ] e.
[ ] f.

# 4. feladat

[ ] a.
[ ] b.
[ ] c.
[ ] d.
[ ] e.
[ ] f.
[ ] g.