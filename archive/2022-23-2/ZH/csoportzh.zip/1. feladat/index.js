// 1. feladat megoldása
