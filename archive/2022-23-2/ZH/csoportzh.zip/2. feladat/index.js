// 2. feladat megoldása

