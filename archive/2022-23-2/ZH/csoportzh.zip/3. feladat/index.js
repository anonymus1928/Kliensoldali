// 3. feladat megoldása

