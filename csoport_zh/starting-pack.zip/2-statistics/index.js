const data = [
    {
        year: 2015,
        semester_spring: 2108,
        semester_autumn: 2367,
        diploma: 301,
    },
    {
        year: 2016,
        semester_spring: 2018,
        semester_autumn: 2635,
        diploma: 334,
    },
    {
        year: 2017,
        semester_spring: 2310,
        semester_autumn: 2771,
        diploma: 324,
    },
    {
        year: 2018,
        semester_spring: 2417,
        semester_autumn: 2871,
        diploma: 437,
    },
    {
        year: 2019,
        semester_spring: 2508,
        semester_autumn: 3138,
        diploma: 430,
    },
    {
        year: 2020,
        semester_spring: 2794,
        semester_autumn: 3400,
        diploma: 729,
    },
    {
        year: 2021,
        semester_spring: 3076,
        semester_autumn: 3529,
        diploma: 693,
    },
    {
        year: 2022,
        semester_spring: 3134,
        semester_autumn: 3630,
        diploma: 683,
    },
    {
        year: 2023,
        semester_spring: 3296,
        semester_autumn: 3910,
        diploma: 771,
    },
];
